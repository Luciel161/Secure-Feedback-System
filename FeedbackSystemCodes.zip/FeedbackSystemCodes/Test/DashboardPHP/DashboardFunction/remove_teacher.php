<?php
    session_start();
    include "../../database.php";
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "admin") {
        header("Location: ../../login.php");
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST["id"];
        $sql = "DELETE FROM users WHERE id = ? AND role = 'teacher'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        header("Location: see_teacher_list.php");
        exit();
    }
?>