<?php
    session_start();
    include("../../navigation.php");
    include "../../database.php";
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "admin") {
        header("Location: ../login.php");
    }

    $search_username = "";
    if (isset($_GET["search"])) {
        $search_username = $_GET["search"];
        $sql = "SELECT id, user_name, username, password_hash FROM users WHERE role = 'teacher' AND username LIKE ?";
        $stmt = $conn->prepare($sql);
        $search_term = "%" . $search_username . "%";
        $stmt->bind_param("s", $search_term);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $sql = "SELECT id, user_name, username, password_hash FROM users WHERE role = 'teacher'";
        $result = $conn->query($sql);

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>See Teachers List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../CSS/see_teacher_list_styles.css">
</head>
<body>
    <div class="teacher-container">
        <h2>List of Teachers</h2>
        <form method="GET" action="see_student_list.php" class="mb-3">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search_username); ?>" placeholder="Search by Teacher ID" class="form-control">
            <button type="submit" class="btn btn-primary mt-2">Search</button>
        </form>
        <?php
            if ($result->num_rows > 0) {
                echo "<table class='table'>
                        <thead>
                            <tr>
                                <th>User's name</th>
                                <th>Username</th>
                                <th>Password</th>";

                
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row["user_name"]) . "</td>
                            <td>" . htmlspecialchars($row["username"]) . "</td>
                            <td>" . htmlspecialchars($row["password_hash"]) . "</td>   
                          </tr>";
                    echo "<td>
                          <form method='POST' action='remove_teacher.php' style='display:inline;'>
                              <input type='hidden' name='id' value='" . $row["id"] . "'>
                              <button type='submit' class='btn btn-danger btn-sm'>Remove</button>
                          </form>
                        </td>
                        </tr>";      
                }
                echo "</tbody>
                    </table>";     
        } else {
            echo "<p>Teacher list is empty!</p>";
        }

        $conn->close();  
        
    ?>
    <a href="../admin_dashboard.php">Back to Admin Dashboard</a>
</body>
</html>