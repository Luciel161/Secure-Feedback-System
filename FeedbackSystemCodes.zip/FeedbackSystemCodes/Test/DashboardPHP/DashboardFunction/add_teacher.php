<?php
    session_start();
    include("../../navigation.php");
    include "../../database.php";
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "admin") {
        header("Location: ../login.php");
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_name = htmlspecialchars($_POST["user_name"]);
        $username = htmlspecialchars($_POST["username"]);
        $password = htmlspecialchars($_POST["password"]);
        if (empty($user_name) || empty($username) || empty($password)) {
            $message = "Insufficient information. Please fill in all fields.";
        } else {
            $password_hash = password_hash($password, PASSWORD_BCRYPT);

            $sql = "INSERT INTO users (user_name, username, password_hash, role) VALUES (?, ?, ?, 'teacher')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $user_name, $username, $password_hash);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                echo "You have added a Teacher!";
            } else {
                echo "An error occured while adding a Teacher!";
            }

            $stmt->close();
            $conn->close();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Teacher function for Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../CSS/add_teacher_styles.css">
</head>
<body>
    <h1>Add New Teacher</h1>
    <form action="add_teacher.php" method="POST">
        <div class="form-group">
            <input type="text" id="user_name" name="user_name" placeholder="Teacher's name:">
        </div>
        <div class="form-group">
            <input type="text" id="username" name="username" placeholder="Username:">
        </div>
        <div class="form-group">
            <input type="password" id="password" name="password" placeholder="Password:">
        </div>
        <div class="form-group">
            <input type="submit" value="Add Teacher">
        </div>

    </form>
    <p><a href="../admin_dashboard.php">Back to Admin Dashboard</a></p>
</body>
</html>