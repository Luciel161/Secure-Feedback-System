<?php
    session_start();
    include "../../database.php";
    if (!isset($_SESSION["username"]) || ($_SESSION["role"] != "teacher" && $_SESSION["role"] != "admin")) {
        header("Location: ../../login.php");
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST["id"];
        //remove student response
        $sql = "DELETE FROM responses WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        //remove student
        $sql = "DELETE FROM users WHERE id = ? AND role = 'student'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        header("Location: see_student_list.php");
        exit();
    }