<?php
    session_start();
    include("../navigation.php");
    include "../database.php";
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "student") {
        header("Location: ../login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/student_dashboard_styles.css">
</head>
<body>
    <div class="student_dashboard">
        <h1>Student Dashboard</h1>
        <a href="../feedback.php?course_id=1">Please provide your feedback to the program here</a>
    </div>
</body>
</html>