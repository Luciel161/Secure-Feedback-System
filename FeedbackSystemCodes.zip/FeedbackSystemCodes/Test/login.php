<?php
    session_start();
    include("database.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = htmlspecialchars($_POST["username"]);
        $password = htmlspecialchars($_POST["password"]);
        if (empty($username) || empty($password)) {
            $message = "Please enter both username and password.";
        } else {

            $sql = "SELECT id, username, password_hash, role FROM users WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($id, $db_username, $password_hash, $role);
            $stmt->fetch();

            if ($stmt->num_rows > 0 && password_verify($password, $password_hash)) {
                $_SESSION["user_id"] = $id;
                $_SESSION["username"] = $db_username;
                $_SESSION["role"] = $role;


                if ($role == "admin") {
                    header("Location: DashboardPHP/admin_dashboard.php");
                } elseif ($role == "teacher") {
                    header("Location: DashboardPHP/teacher_dashboard.php");
                } else {
                    header("Location: DashboardPHP/student_dashboard.php");
                }
                exit();
            } else {
                echo "Username or password not found";
            }

            $stmt->close();
            $conn->close();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/login_styles.css">
</head>
<body>
    <div class="container">
        <div class="login_section">
            <div class="login_content">
                <div class="page_name">
                    <div>C.A.S.T</div>
                    <div>Feedback</div>
                    <div>System</div>
                </div>
                <form class="login" action="login.php" method="post">
                    <div class="login_field">
                        <input type="text" class="login_input" id="username" name="username" placeholder="Username">
                    </div>
                    <div class="login_field">
                        <input type="password" class="login_input" id="password" name="password" placeholder="Password:">
                    </div>
                    <button type="submit" class="submit_button">
                        <span class="button_text">Login</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

