<?php
    if (!isset($_SESSION["username"])) {
        header("Location: /Test/login.php");
        exit();
    }

    $role = $_SESSION["role"];
?>

<link rel="stylesheet" href="/Test/CSS/navigation_styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<nav class="navbar">
    <div class="navbar-container container">
        <input type="checkbox" id="menu-toggle">
        <label class="hamburger-lines" for="menu-toggle">
            <span class="line line1"></span>
            <span class="line line2"></span>
            <span class="line line3"></span>
        </label>
        <ul class="nav-items">
            <?php if ($role == "admin"): ?>
                <li><a href="/Test/DashboardPHP/admin_dashboard.php">Dashboard</a></li>
                <li><a href="/Test/DashboardPHP/DashboardFunction/see_teacher_list.php">Teacher List</a></li>
                <li><a href="/Test/DashboardPHP/DashboardFunction/see_student_list.php">Student List</a></li>
            <?php elseif ($role == "teacher"): ?>
                <li><a href="/Test/DashboardPHP/teacher_dashboard.php">Dashboard</a></li>
                <li><a href="/Test/DashboardPHP/DashboardFunction/see_student_list.php">Student List</a></li>
            <?php elseif ($role == "student"): ?>
                <li><a href="/Test/DashboardPHP/student_dashboard.php">Dashboard</a></li>
                <li><a href="/Test/DashboardPHP/feedback.php">Feedback</a></li>
            <?php endif; ?>
            <li><a href="/Test/logout.php">Logout</a></li>
        </ul>
    </div>
</nav>
