<?php
    session_start();
    include("navigation.php");
    include("database.php");

    //Go back to login if user is not student
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "student") {
        header("Location: login.php");
        exit();
    }

    $course_id = $_GET["course_id"];

    //Get feedback questions to the course
    $feedback_question_sql = "SELECT id, question_text, question_type from feedback_question where course_id =?";
    $feedback_question_stmt = $conn->prepare($feedback_question_sql);
    $feedback_question_stmt->bind_param("i", $course_id);
    $feedback_question_stmt->execute();
    $feedback_question_result = $feedback_question_stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/feedback_styles.css">
</head>
<body>
    <div class="feedback-container">
        <h1>Feedback Form</h1>
        <form action="submit_feedback.php" method="post">
            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
            <?php while ($row = $feedback_question_result->fetch_assoc()) { ?>
                <div class="question">
                    <p><?php echo $row['question_text']; ?></p>
                    <?php if ($row['question_type'] == "multiple_choice") {
                        $options_sql = "SELECT id, option_text FROM options WHERE question_id = ?";
                        $options_stmt = $conn->prepare($options_sql);
                        $options_stmt->bind_param("i", $row['id']);
                        $options_stmt->execute();
                        $options_result = $options_stmt->get_result();
                        while ($option = $options_result->fetch_assoc()) { ?>
                            <input type="radio" name="question_<?php echo $row['id']; ?>" value="<?php echo $option['id']; ?>"><?php echo $option['option_text']; ?><br>
                        <?php }

                    } else { ?>
                        <input type="text" name="question_<?php echo $row['id']; ?>"><br>
                    <?php } ?>
                </div>
            <?php } ?>
            <input type="submit" value="Submit Feedback">
        </form>
    </div>
</body>
</html>

