<?php
    session_start();
    include("database.php");

    //Go back to login if user is not student
    if (!isset($_SESSION["username"]) || $_SESSION["role"] != "student") {
        header("Location: login.php");
        exit();
    }

    //get user ID and course ID
    $user_id = $_SESSION['user_id'];
    $course_id = $_POST['course_id'];

    foreach ($_POST as $key => $value) {
        if (strpos($key, "question_") === 0) {
            $question_id = str_replace("question_", "", $key);

            $stmt = $conn->prepare("SELECT question_type FROM feedback_question WHERE id = ?");
            $stmt->bind_param("i", $question_id);
            $stmt->execute();
            $result = $stmt->get_result();


            if ($result->num_rows > 0) {
                $question = $result->fetch_assoc();

                if ($question["question_type"] == "multiple_choice") {
                    $option_id = $value;
                    $stmt = $conn->prepare("INSERT INTO responses (user_id, question_id, option_id) VALUES (?,?,?)");
                    $stmt->bind_param("iii", $user_id, $question_id, $option_id);
                } else {
                    $response_text = $value;
                    $stmt = $conn->prepare("INSERT INTO responses (user_id, question_id, response_text) VALUES (?,?,?)");
                    $stmt->bind_param("iis", $user_id, $question_id, $response_text);
                }

                $stmt->execute();
                $stmt->close();
            } else {
                echo "An error occured";
            }
           
        } 
    }

    header("Location: DashboardPHP/student_dashboard.php");
exit();
