<?php
    session_start();
    include("navigation.php");
    include "database.php";

    if (!isset($_SESSION["username"]) || ($_SESSION["role"] != "teacher" && $_SESSION["role"] != "admin")) {
        header("Location: login.php");
        exit();
    }

    //get feedback
    $questions_sql = "SELECT id, question_text FROM feedback_question WHERE course_id = 1";
    $questions_result = $conn->query($questions_sql);

    $feedback_data = [];
    while ($question = $questions_result->fetch_assoc()) {
        $question_id = $question["id"];
        $question_text = $question["question_text"];

        $options_sql = "SELECT id, option_text FROM options WHERE question_id = ?";
        $options_stmt = $conn->prepare($options_sql);
        $options_stmt->bind_param("i", $question_id);
        $options_stmt->execute();
        $options_result = $options_stmt->get_result();

        $options_data = [];
        while ($option = $options_result->fetch_assoc()) {
            $option_id = $option["id"];
            $option_text = $option["option_text"];

            $count_sql = "SELECT COUNT(*) as count FROM responses WHERE question_id = ? AND option_id = ?";
            $count_stmt = $conn->prepare($count_sql);
            $count_stmt->bind_param("ii", $question_id, $option_id);
            $count_stmt->execute();
            $count_result = $count_stmt->get_result();
            $count = $count_result->fetch_assoc()["count"];

            $options_data[] = [
                "option_text" => $option_text,
                "count" => $count
            ];
        }

        $feedback_data[] = [
            "question_text" => $question_text,
            "options" => $options_data
        ];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>See Feedback</title>
    <link rel="stylesheet" href="CSS/see_feedback_styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <script>
        var feedbackResult = <?php echo json_encode($feedback_data); ?>;
    </script>
    <script src="JS/charts_feedback.js"></script>
</head>
<body>
    <div class="feedback-container">
        <h1>Feedback Results</h1>

        <?php foreach ($feedback_data as $index => $question) { ?>
            <h2><?php echo htmlspecialchars($question["question_text"]); ?></h2>
            <canvas id="chart-<?php echo $index; ?>"width = "400" height = "200"></canvas>
        <?php } ?>
    </div>
</body>
</html>

